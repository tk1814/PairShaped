  
<html lang="en">
<head>
    <title>PairShaped</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Abril+Fatface&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
<body>





<div id="colorlib-page">
		<a href="#" class="js-colorlib-nav-toggle colorlib-nav-toggle"><i></i></a>
		<aside id="colorlib-aside" role="complementary" class="js-fullheight" style="background: #57b846">
			<nav id="colorlib-main-menu" role="navigation">
					<img src="wordlogo.png" alt="Flowers in Chania" style=" display: block; margin-left: auto; margin-right: auto; width:100%" >
					<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		

					<div class="card  p-t-250">
					  <img src="icon.png" alt="Neha" style="width:100%">
					  <h1><?php echo $_GET["name"]; ?></h1>
					  <p class="title">Skills: <?php echo $_GET["skills"]; ?></p>
					  <p class="title">Interests: <?php echo $_GET["interests"]; ?></p>
					</div>
					
					</form>
			</nav>
          </form>

		</aside> <!-- END COLORLIB-ASIDE -->
		<div id="colorlib-main">
			<section class="ftco-section ftco-no-pt ftco-no-pb">
	    	<div class="container">
	    		<div class="row d-flex">
	    			<div class=" py-5 px-md-5">
	    				<div class="row pt-md-4">
										<?php
$usrInterests = $_GET["interests"];
$mikeArr = array("Mike", "Swimming,Tango, Drums, Tennis, Acrobatics, Acting, Animation", "Swimming");
$jamesArr = array("James", "Swimming, HopScotch, Baking, Baton twirling, Beatboxing, Blogging", "Swimming");
$harshArr = array("Harsh", "Pressed flower craft, Playing musical instruments, Poi, Pottery, Puzzles", "Cycling");
$ancaArr = array("Anca", "Pressed flower craft, Playing musical instruments, Poi, Pottery, Puzzles", "Swimming");
$ericArr = array("Eric", "Lego building, Lock picking, Listening to music, Listening to podcasts", "Running");
$adrianaArr = array("Adriana", "Welding, Programming, Scuba Diving", "Cycling");
$images = array("asdf.jpg", "james.jpg","Harsh.jpg", "Anca.jpg", "Eric.jpg", "Adriana.jpg");
$peopleArray = array($mikeArr, $jamesArr, $harshArr, $ancaArr, $ericArr, $adrianaArr);
$matchFound = false;
for ($x = 0; $x < count($peopleArray); $x++) {
    if (strtolower($usrInterests) == strtolower($peopleArray[$x][2])){
				echo '<div class="col-md-12">
				<div class="blog-entry ftco-animate d-md-flex">
					<a href="single.html" class="img img-2" style="background-image: url(images/' . $images[$x] .');"></a>
					<div class="text text-2 pl-md-4">
		<h3 class="mb-2"><a href="single.html">' . $peopleArray[$x][0] .'</a></h3>
		<div class="meta-wrap">
							<p class="meta">
				<span></i>Manchester</span>
				
			</p>
		</div>
		<p class="mb-4">Skills: '. $peopleArray[$x][1] .'</p>
		<p class="mb-4">'. $peopleArray[$x][2] .'</p>

		<p><a href="#" class="btn-custom">Contact <span class="ion-ios-arrow-forward"></span></a></p>

		</div>
				</div>'."<br>";
				$matchFound = true;
			}
}
if (!$matchFound) {
    echo "No matches found. Sorry.<br>";
}
?>
			    		</div><!-- END-->
			    		<div class="row">
			          <div class="col">

			          </div>
			        </div>
			    	</div>
	    			

	          </div><!-- END COL -->
	    		</div>
	    	</div>
	    </section>
		</div><!-- END COLORLIB-MAIN -->
	</div><!-- END COLORLIB-PAGE -->

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>

</body>
</html>